<div class="mt-8">
    <a href="<?php echo e(route('movies.show', $movie['id'])); ?>">
        <img src="<?php echo e($movie['poster_path']); ?>" alt="parasite"
            class="hover:opacity-75 transition ease-in-out duration-150">
    </a>
    <div class="mt-2">
        <a href="<?php echo e(route('movies.show', $movie['id'])); ?>"
            class="text-lg mt-2 hover:text-gray-300"><?php echo e($movie['title']); ?></a>
        <div class="flex items-center text-gray-400">
            <span><i class="fas fa-star fill-current text-yellow-500 w-4"></i></span>
            <span class="ml-1"><?php echo e($movie['vote_average']); ?></span>
            <span class="mx-2">|</span>
            <span><?php echo e($movie['release_date']); ?></span>
        </div>
        <div class="text-gray-400"><?php echo e($movie['genres']); ?></div>
    </div>
</div><?php /**PATH C:\wamp64\www\laravel-movies\resources\views/components/movie-card.blade.php ENDPATH**/ ?>