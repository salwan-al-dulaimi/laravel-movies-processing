<?php $__env->startSection('content'); ?>
    <div class="movie-info border-b border-gray-800">
        <div class="container mx-auto px-4 py-16 flex flex-col md:flex-row">
            <div class="flex-none">
                <img src="<?php echo e($actor['profile_path']); ?>" alt="poster" class="w-64 lg:w-96">
                <ul class="flex items center mt-4">
                    <?php if($social['facebook']): ?>
                    <a href="<?php echo e($social['facebook']); ?>" title="Facebook"  target="_blank"><i class="fab fa-facebook-square fa-2x mr-2  text-gray-400"></i></a>
                    <?php endif; ?>
                    <?php if($social['instagram']): ?>
                    <a href="<?php echo e($social['instagram']); ?>" title="Instagram"  target="_blank"><i class="fab fa-instagram-square fa-2x mr-2 text-gray-400"></i></a>
                    <?php endif; ?>
                    <?php if($social['twitter']): ?>
                    <a href="<?php echo e($social['twitter']); ?>" title="Twitter"  target="_blank"><i class="fab fa-twitter-square fa-2x mr-2 text-gray-400"></i></a>
                    <?php endif; ?>
                    <?php if($actor['homepage']): ?>
                    <a href="<?php echo e($actor['homepage']); ?>" title="Website"  target="_blank"><i class="fas fa-globe fa-2x mr-2 text-gray-400"></i></a>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="md:ml-24">
                <h2 class="text-4xl mt-4 md:mt-0 font-semibold"><?php echo e($actor['name']); ?></h2>
                <div class="flex flex-wrap items-center text-gray-400 text-sm mt-1">
                    <i class="fas fa-birthday-cake"></i><span class="ml-1"><?php echo e($actor['birthday']); ?></span>
                    
                    <span class="mx-2">(<?php echo e($actor['age']); ?> Years old)</span>
                    <span class="mx-2">|</span>
                    <span class="mx-2"><i class="fas fa-map-marker-alt mr-1"></i><?php echo e($actor['place_of_birth']); ?></span>
                </div>

                <p class="text-gray-300 mt-8"><?php echo e($actor['biography']); ?></p>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
                    <?php $__currentLoopData = $knownForMovies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mt-4">
                        <a href="<?php echo e($movie['linkToPage']); ?>"><img src="<?php echo e($movie['poster_path']); ?>" alt="poster" class="hover:opacity-75 transition ease-in-out duration-150"></a>
                            <a href="<?php echo e($movie['linkToPage']); ?>" class="text-sm leading-normal block text-gray-400 hover:text-white mt-1"><?php echo e($movie['title']); ?></a>
                    </div>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>
    </div> <!-- end credits-info -->

    <div class="credits border-b border-gray-800">
        <div class="container mx-auto px-4 py-16">
            <h2 class="text-4xl font-semibold">Credits</h2>

            <ul class="list-disc leading-loose pl-5 mt-8">
                <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($credit['release_year']); ?>  &middot; <strong><?php echo e($credit['title']); ?></strong> as <?php echo e($credit['character']); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>
            
        </div>
    </div> <!-- end credits -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-movies\resources\views/actors/show.blade.php ENDPATH**/ ?>