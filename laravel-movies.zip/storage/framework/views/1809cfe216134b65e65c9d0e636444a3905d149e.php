<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-16 pt-16">
        <div class="popular-movies">
            <h2 class="uppercase tracking-wider text-yellow-500 text-lg font-semibold">Popular Movies</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mt-8">
                    <a href="<?php echo e(route('movies.show', $movie['id'])); ?>">
                        <img src="<?php echo e('https://image.tmdb.org/t/p/w500/'.$movie['poster_path']); ?>" alt="parasite"
                            class="hover:opacity-75 transition ease-in-out duration-150">
                    </a>
                    <div class="mt-2">
                        <a href="<?php echo e(route('movies.show', $movie['id'])); ?>"
                            class="text-lg mt-2 hover:text-gray-300"><?php echo e($movie['title']); ?></a>
                        <div class="flex items-center text-gray-400">
                            <span><i class="fas fa-star fill-current text-yellow-500 w-4"></i></span>
                            <span class="ml-1"><?php echo e($movie['vote_average']); ?></span>
                            <span class="mx-2">|</span>
                            <?php if(isset($movie['release_date'])): ?>
                                <span><?php echo e($movie['release_date']); ?></span>
                            <?php endif; ?>                          
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class=" pt-16">
            <div class="popular-movies">
                <h2 class="uppercase tracking-wider text-yellow-500 text-lg font-semibold">New playing</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8">
                    
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-movies\resources\views/genres/show.blade.php ENDPATH**/ ?>